#!/home/groupc/anaconda3/envs/team3_gene_prediction/bin/python

import argparse
import shlex,subprocess
import os

parser = argparse.ArgumentParser()
parser.add_argument('-i', type = str, required = True, help='Input folder path containing contigs')
parser.add_argument('-o',type = str, required = True, help='Output folder path')
args = parser.parse_args()
print('test')
print(args.o)

out = os.getcwd()+'/'+args.o
input = os.getcwd()+'/'+args.i
print(out)
files = os.listdir(args.i)

os.makedirs(args.o+"/prodigal_output_tool", exist_ok=True)
os.makedirs(args.o+"/genemarks_out", exist_ok=True)
os.makedirs(args.o+"/Merged_gffs", exist_ok=True)

# Prodigal
for f in files:
    if (f.endswith(".fasta")):
        pref = (f.split(".")[0])
        path = input+"/"+f
        outdir = out+"/prodigal_output_tool/"+pref
        os.system("prodigal -i " + path + " -d " + outdir + "_Output.fasta" + " -f gff -o " + outdir + "_Output.gff")

print("------------------------------------")
print("Gene Mark S2") 
print("------------------------------------")  
# Gene Mark s2
for f in files:
    if (f.endswith(".fasta")):
        pref = (f.split(".")[0])
        path = input+"/"+f
        outdir1 = args.o+"/genemarks_out/"+pref
        os.system("gms2.pl --genome-type bacteria --seq " + path + " --output " + outdir1 + ".gff")
        print("Done with "+pref)

print("------------------------------------")
print("Merging all gffs") 
print("------------------------------------")  

# Merge both
genePredictionFolder = os.path.dirname(__file__)
#os.system(genePredictionFolder+"/files/gffcomb.sh -p "+args.o+"/prodigal_output_tool"+" -g "+args.o+"/genemarks_out"+" -r "+args.i)

print("***************************************")
print("Thank you") 
print("**************************************")  
