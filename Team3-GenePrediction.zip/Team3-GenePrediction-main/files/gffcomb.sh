#!/bin/bash
# Author: Colin Naughton
# Combines multiple gff files from Prodigal and GeneMarkS-2
# Assumes the gffs are in different directories for each tool.

#---------------Set Variables--------------------------------------------
PRODIGAL_DIR=NULL
GENEMARKS_DIR=NULL
ASSEMBLY_DIR=NULL
OUTPUT_DIR=NULL
#---------------------------------Usage Function--------------------------------------------
usage(){ 
echo "Usage: gffcomb.sh [-p] <Prodigal gff Directory> [-g] <GeneMarkS-2 gff Directory> [-r] <Assemblies Directory> [-o] <Output Directory>"
echo "Output: Combined gtf files and their corresponding fasta files in the current directory; Output format: <isolate name>.combined.gtf/fa"
echo "Requirements: gffcompare and gffread in your bin"; 
} 
#----------------------------Get User Inputs (getops)----------------------------------------
while getopts "p:g:r:o:h" option 
	do
		case $option in
			p) PRODIGAL_DIR=$OPTARG;; # Directory with gff files produced by Prodigal
			g) GENEMARKS_DIR=$OPTARG;; # Directory with gff files produced by GeneMarkS-2
			r) ASSEMBLY_DIR=$OPTARG;; # Directory with fasta file assemblies that the gff files are based on.
			o) OUTPUT_DIR=$OPTARG;; # Directory to place output fasta/gtf files.
			h) usage; exit 1;; # Print usage information and exit
		esac
	done

#Get locations of gffs for each tool and isolate names, and place 
find $PRODIGAL_DIR -name '*.gff' | sort > prodigalGffLoc.txt
find $GENEMARKS_DIR -name '*.gff' | sort > genemarksGffLoc.txt
find $ASSEMBLY_DIR -name '*.fasta' | sort > assemblyLoc.txt
find $ASSEMBLY_DIR -name '*.fasta' | sort |sed 's!.*/!!' | sed 's/_contigs\..*$//'  > isolateNames.txt # Create list of isolate names for using as out file prefixes
paste prodigalGffLoc.txt genemarksGffLoc.txt isolateNames.txt assemblyLoc.txt > gffLocs.txt


#Combine gffs
while read -r col1 col2 col3 col4; 
	do 
		gffcompare -T -o ${OUTPUT_DIR}/${col3} $col1 $col2;
		gffread -w ${OUTPUT_DIR}/${col3}.combined.fa -g $col4 ${OUTPUT_DIR}/${col3}.combined.gtf
	done < gffLocs.txt
ls ${OUTPUT_DIR}/*combined.gtf | xargs sed -i '/transcript\t/d' # Remove duplicate lines that appear in final gtf; removed exactly half of the entries for my test case.

#Remove unnecessary files produced when combining gffs
rm ${OUTPUT_DIR}/*.tracking ${OUTPUT_DIR}/*.loci ${OUTPUT_DIR}/*.stats

#Remove files related to locations of original gff files
rm prodigalGffLoc.txt genemarksGffLoc.txt isolateNames.txt gffLocs.txt assemblyLoc.txt
