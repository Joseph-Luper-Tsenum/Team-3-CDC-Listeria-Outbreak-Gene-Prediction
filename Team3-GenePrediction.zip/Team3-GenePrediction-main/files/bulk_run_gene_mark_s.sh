#!/bin/bash

mkdir -p genemarks_out
valid_file="[\.fasta$]"

dir_name=$(dirname "$0")
for i in "$@"
do
    if [[ $i =~ $valid_file ]]; then
        outpath=`echo "${i##*/}"| sed -e 's/\.fasta$/_genemarks_out.gff/g'`
        echo "Processing ${i}"
        python "${dir_name}/gene_mark_s.py" -i "${i}" -o "genemarks_out/${outpath}" 
        echo "Output to ${outpath}"
    fi
done
