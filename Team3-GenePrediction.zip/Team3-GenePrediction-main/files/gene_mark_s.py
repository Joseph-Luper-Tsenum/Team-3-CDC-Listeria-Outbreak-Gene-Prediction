#!/home/groupc/anaconda3/envs/team3_gene_prediction/bin/python

import requests
from pyquery import PyQuery # use pip to install this

import argparse

parser = argparse.ArgumentParser(description='Run GeneMarkS')
parser.add_argument("-i", "--input", required=True, help="Input file path")
parser.add_argument("-o", "--output", required=True, help="Directs the output to a name of your choice")

args = parser.parse_args()

# Form submission (with options selected)
payload = {
    'format': 'gff3',
    'fnn': 'fnn',
    'gocde': '11',
    'mode': 'auto',
    'submit': 'Start GeneMarkS-2'
}

# Input file provided here
files = {
    'file': open( args.input, 'rb')
}

# Starts the connection to the GeneMarkS website and submit file & options
session = requests.Session()

r = session.post('http://exon.gatech.edu/GeneMark/genemarks2.cgi', data=payload, files=files, timeout=None)

pg = PyQuery( r.content )

# Parse the output to find the temp file name
temp_file_name = pg('body').find('table').eq(1).find('tr').eq(3).find('tr').eq(1).find('a').attr['href']

# Constructs the final url for the output fnn file
final_url = 'http://exon.gatech.edu/GeneMark/{}'.format(temp_file_name)

# Fetches the final fnn output file
r = requests.get(final_url)

# Writes the output file to local path
outfile_f = open(args.output, 'wb')
outfile_f.write( r.content )
outfile_f.close()