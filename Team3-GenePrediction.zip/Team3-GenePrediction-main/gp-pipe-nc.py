#!/home/groupc/anaconda3/bin/python

import argparse
import shlex,subprocess
import os

parser = argparse.ArgumentParser()
parser.add_argument('-i', type = str, required = True, help='Input folder path containing contigs')
parser.add_argument('-o', type = str, required = True,help='Output folder path')
args = parser.parse_args()

files = os.listdir(args.i)

# Prokka - NC
for f in files:
    if (f.endswith(".fasta")):
        pref = (f.split(".")[0])
        path = args.i+"/"+f
        outdir = args.o+"/"+pref
        #retval = subprocess.call(shlex.split("prokka --outdir "+outdir+" --prefix "+pref+" --quiet "+path+ " --force"))
        os.system("prokka --outdir "+outdir+" --prefix "+pref+" --quiet "+path+ " --force")



